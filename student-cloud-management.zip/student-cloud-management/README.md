# Secure Cloud-Based Student Management System

A Flask-based student management application for a secure cloud deployment architecture. The project includes student registration, login, profile management, course enrollment, and an admin dashboard.

## Features
- Student registration and login
- Password hashing with Werkzeug
- Session-based role-based access control
- Student profile updates and document/photo upload handling
- Course registration dashboard
- Admin dashboard for managing students and course records
- MySQL configuration via environment variables
- AWS S3-ready file upload logic using IAM-based credentials
- Local upload fallback for development

## Local setup
1. Create a virtual environment
2. Install dependencies:
   pip install -r requirements.txt
3. Copy .env.example to .env and update values
4. Run the app:
   python app.py

## Production architecture notes
- Flask app runs behind Gunicorn on EC2
- MySQL is hosted on RDS in a private subnet
- EC2 uses IAM roles to access S3 without embedded credentials
- Security groups and VPC configuration restrict database access
- Nginx can be placed in front of Gunicorn for reverse proxying

## Default admin login
- Email: admin@college.edu
- Password: admin123

## Important security note
- Never commit .env values or secret keys to GitHub
- Use IAM roles and least-privilege policies in AWS
- Restrict database and S3 permissions to the minimum required
