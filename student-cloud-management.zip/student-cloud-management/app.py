import os
from datetime import datetime

from flask import Flask, flash, redirect, render_template, request, send_from_directory, session, url_for
from werkzeug.security import check_password_hash, generate_password_hash
from werkzeug.utils import secure_filename

from config import Config

COURSES = [
    {"code": "CS101", "name": "Introduction to Programming", "credits": 3},
    {"code": "CS201", "name": "Data Structures", "credits": 4},
    {"code": "DB301", "name": "Database Design", "credits": 3},
    {"code": "SEC401", "name": "Cybersecurity Fundamentals", "credits": 3},
    {"code": "WEB110", "name": "Web Application Development", "credits": 3},
]


def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    USER_STORE = {
        "admin@college.edu": {
            "name": "System Administrator",
            "email": "admin@college.edu",
            "password": generate_password_hash("admin123"),
            "role": "admin",
            "course": "Administration",
            "phone": "+1-555-0100",
            "address": "Campus Office",
            "photo_url": None,
            "documents": [],
            "created_at": datetime.utcnow().isoformat(),
        }
    }

    def get_logged_user():
        email = session.get("user")
        if not email:
            return None
        return USER_STORE.get(email)

    def save_uploaded_file(file_obj):
        if not file_obj or not file_obj.filename:
            return None

        filename = secure_filename(file_obj.filename)

        if Config.s3_enabled():
            try:
                import boto3

                s3 = boto3.client(
                    "s3",
                    region_name=app.config["AWS_REGION"],
                    aws_access_key_id=app.config["AWS_ACCESS_KEY_ID"],
                    aws_secret_access_key=app.config["AWS_SECRET_ACCESS_KEY"],
                )
                s3.upload_fileobj(
                    file_obj,
                    app.config["AWS_S3_BUCKET"],
                    filename,
                )
                return f"https://{app.config['AWS_S3_BUCKET']}.s3.{app.config['AWS_REGION']}.amazonaws.com/{filename}"
            except Exception as exc:
                flash(f"S3 upload failed: {exc}", "danger")
                return None

        upload_dir = os.path.join(app.root_path, app.config["UPLOAD_FOLDER"])
        os.makedirs(upload_dir, exist_ok=True)
        file_path = os.path.join(upload_dir, filename)
        file_obj.save(file_path)
        return f"/uploads/{filename}"

    @app.route("/")
    def home():
        return render_template("index.html")

    @app.route("/register", methods=["GET", "POST"])
    def register():
        if request.method == "POST":
            name = request.form.get("name", "").strip()
            email = request.form.get("email", "").strip().lower()
            password = request.form.get("password", "")
            course = request.form.get("course", "").strip()

            if not all([name, email, password, course]):
                flash("Please complete all required fields.", "danger")
                return render_template("register.html")

            if email in USER_STORE:
                flash("This email is already registered.", "warning")
                return render_template("register.html")

            USER_STORE[email] = {
                "name": name,
                "email": email,
                "password": generate_password_hash(password),
                "role": "student",
                "course": course,
                "phone": "",
                "address": "",
                "photo_url": None,
                "documents": [],
                "created_at": datetime.utcnow().isoformat(),
            }

            flash("Registration successful. You can now log in.", "success")
            return redirect(url_for("login"))

        return render_template("register.html")

    @app.route("/login", methods=["GET", "POST"])
    def login():
        if request.method == "POST":
            email = request.form.get("email", "").strip().lower()
            password = request.form.get("password", "")

            user = USER_STORE.get(email)
            if user and check_password_hash(user["password"], password):
                session["user"] = user["email"]
                session["role"] = user["role"]
                flash("Login successful.", "success")
                return redirect(url_for("dashboard"))

            flash("Invalid email or password.", "danger")

        return render_template("login.html")

    @app.route("/dashboard")
    def dashboard():
        user = get_logged_user()
        if not user:
            return redirect(url_for("login"))
        return render_template("dashboard.html", user=user)

    @app.route("/profile", methods=["GET", "POST"])
    def profile():
        user = get_logged_user()
        if not user:
            return redirect(url_for("login"))

        if request.method == "POST":
            user["phone"] = request.form.get("phone", "").strip()
            user["address"] = request.form.get("address", "").strip()
            user["course"] = request.form.get("course", user["course"]).strip()

            uploaded_file = request.files.get("document")
            if uploaded_file and uploaded_file.filename:
                file_url = save_uploaded_file(uploaded_file)
                if file_url:
                    user["documents"].append(file_url)
                    flash("Document uploaded securely.", "success")

            upload_photo = request.files.get("photo")
            if upload_photo and upload_photo.filename:
                file_url = save_uploaded_file(upload_photo)
                if file_url:
                    user["photo_url"] = file_url
                    flash("Profile photo updated.", "success")

            flash("Profile updated successfully.", "success")
            return redirect(url_for("profile"))

        return render_template("profile.html", user=user)

    @app.route("/courses", methods=["GET", "POST"])
    def courses():
        user = get_logged_user()
        if not user:
            return redirect(url_for("login"))

        if request.method == "POST":
            selected_course = request.form.get("course_code")
            if selected_course:
                user["course"] = selected_course
                flash("Course registration saved.", "success")
            return redirect(url_for("courses"))

        return render_template("courses.html", user=user, course_list=COURSES)

    @app.route("/admin")
    def admin():
        user = get_logged_user()
        if not user:
            return redirect(url_for("login"))
        if user["role"] != "admin":
            return "Access denied", 403

        students = [record for record in USER_STORE.values() if record["role"] == "student"]
        return render_template("admin.html", user=user, students=students, course_list=COURSES)

    @app.route("/uploads/<path:filename>")
    def uploaded_file(filename):
        upload_dir = os.path.join(app.root_path, app.config["UPLOAD_FOLDER"])
        return send_from_directory(upload_dir, filename)

    @app.route("/logout")
    def logout():
        session.clear()
        flash("You have been logged out.", "success")
        return redirect(url_for("home"))

    os.makedirs(os.path.join(app.root_path, app.config["UPLOAD_FOLDER"]), exist_ok=True)
    return app


app = create_app()


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)