bind = "0.0.0.0:8000"
workers = 2
threads = 2
worker_class = "sync"
accesslog = "-"
errorlog = "-"
