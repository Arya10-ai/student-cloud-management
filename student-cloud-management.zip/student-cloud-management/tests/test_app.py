import pytest
from app import create_app


@pytest.fixture
def client():
    app = create_app()
    app.config["TESTING"] = True
    with app.test_client() as client:
        yield client


def test_home_page(client):
    response = client.get("/")
    assert response.status_code == 200


def test_login_page(client):
    response = client.get("/login")
    assert response.status_code == 200


def test_register_page(client):
    response = client.get("/register")
    assert response.status_code == 200


def test_admin_requires_login(client):
    response = client.get("/admin")
    assert response.status_code == 302


def test_valid_admin_login(client):
    response = client.post(
        "/login",
        data={"email": "admin@college.edu", "password": "admin123"},
        follow_redirects=True,
    )
    assert response.status_code == 200
    assert b"Welcome" in response.data
